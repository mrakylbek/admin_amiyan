import 'package:admin_panel_amiyan/controllers/menu_controller.dart';
import 'package:admin_panel_amiyan/controllers/navigation_controller.dart';

MenuController menuController = MenuController.instance;

NavigationController navigationController = NavigationController.instance;







